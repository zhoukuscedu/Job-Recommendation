create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2019-09-18 07:35:36'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

